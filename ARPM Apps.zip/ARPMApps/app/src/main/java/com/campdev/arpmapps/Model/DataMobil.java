package com.campdev.arpmapps.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class DataMobil  {

    String id_mobilall;
    String id_mobil_daihatsu;
    String id_mobil_toyota;
    String id_mobil_honda;

    String link_img_all;
    String link_img_daihatsu;
    String link_img_toyota;
    String link_img_honda;

    String nama_mobil;
    String nama_mobil_daihatsu;
    String nama_mobil_toyota;
    String nama_mobil_honda;

    String varian_mobil;
    String varian_mobil_daihatsu;
    String varian_mobil_toyota;
    String varian_mobil_honda;

    String tipebody_mobil_all;
    String tipebody_mobil_daihatsu;
    String tipebody_mobil_toyota;
    String tipebody_mobil_honda;

    String bb_mobil;
    String bb_mobil_daihatsu;
    String bb_mobil_toyota;
    String bb_mobil_honda;

    String transmisi_mobil;
    String transmisi_mobil_daihatsu;
    String transmisi_mobil_toyota;
    String transmisi_mobil_honda;

    String harga_mobil;
    String harga_mobil_daihatsu;
    String harga_mobil_toyota;
    String harga_mobil_honda;

    String desc_mobil_all;
    String desc_mobil_daihatsu;
    String desc_mobil_toyota;
    String desc_mobil_honda;

    String alamat_dealer_mobil_all;
    String alamat_dealer_mobil_daihatsu;
    String alamat_dealer_mobil_toyota;
    String alamat_dealer_mobil_honda;

    String no_tlp_mobil_all;
    String no_tlp_mobil_daihatsu;
    String no_tlp_mobil_toyota;
    String no_tlp_mobil_honda;

    public String getId_mobil_daihatsu() {
        return id_mobil_daihatsu;
    }

    public void setId_mobil_daihatsu(String id_mobil_daihatsu) {
        this.id_mobil_daihatsu = id_mobil_daihatsu;
    }

    public String getId_mobil_toyota() {
        return id_mobil_toyota;
    }

    public void setId_mobil_toyota(String id_mobil_toyota) {
        this.id_mobil_toyota = id_mobil_toyota;
    }

    public String getId_mobil_honda() {
        return id_mobil_honda;
    }

    public void setId_mobil_honda(String id_mobil_honda) {
        this.id_mobil_honda = id_mobil_honda;
    }

    public String getLink_img_daihatsu() {
        return link_img_daihatsu;
    }

    public void setLink_img_daihatsu(String link_img_daihatsu) {
        this.link_img_daihatsu = link_img_daihatsu;
    }

    public String getLink_img_toyota() {
        return link_img_toyota;
    }

    public void setLink_img_toyota(String link_img_toyota) {
        this.link_img_toyota = link_img_toyota;
    }

    public String getLink_img_honda() {
        return link_img_honda;
    }

    public void setLink_img_honda(String link_img_honda) {
        this.link_img_honda = link_img_honda;
    }

    public String getNama_mobil_daihatsu() {
        return nama_mobil_daihatsu;
    }

    public void setNama_mobil_daihatsu(String nama_mobil_daihatsu) {
        this.nama_mobil_daihatsu = nama_mobil_daihatsu;
    }

    public String getNama_mobil_toyota() {
        return nama_mobil_toyota;
    }

    public void setNama_mobil_toyota(String nama_mobil_toyota) {
        this.nama_mobil_toyota = nama_mobil_toyota;
    }

    public String getNama_mobil_honda() {
        return nama_mobil_honda;
    }

    public void setNama_mobil_honda(String nama_mobil_honda) {
        this.nama_mobil_honda = nama_mobil_honda;
    }

    public String getVarian_mobil_daihatsu() {
        return varian_mobil_daihatsu;
    }

    public void setVarian_mobil_daihatsu(String varian_mobil_daihatsu) {
        this.varian_mobil_daihatsu = varian_mobil_daihatsu;
    }

    public String getVarian_mobil_toyota() {
        return varian_mobil_toyota;
    }

    public void setVarian_mobil_toyota(String varian_mobil_toyota) {
        this.varian_mobil_toyota = varian_mobil_toyota;
    }

    public String getVarian_mobil_honda() {
        return varian_mobil_honda;
    }

    public void setVarian_mobil_honda(String varian_mobil_honda) {
        this.varian_mobil_honda = varian_mobil_honda;
    }

    public String getTipebody_mobil_daihatsu() {
        return tipebody_mobil_daihatsu;
    }

    public void setTipebody_mobil_daihatsu(String tipebody_mobil_daihatsu) {
        this.tipebody_mobil_daihatsu = tipebody_mobil_daihatsu;
    }

    public String getTipebody_mobil_toyota() {
        return tipebody_mobil_toyota;
    }

    public void setTipebody_mobil_toyota(String tipebody_mobil_toyota) {
        this.tipebody_mobil_toyota = tipebody_mobil_toyota;
    }

    public String getTipebody_mobil_honda() {
        return tipebody_mobil_honda;
    }

    public void setTipebody_mobil_honda(String tipebody_mobil_honda) {
        this.tipebody_mobil_honda = tipebody_mobil_honda;
    }

    public String getBb_mobil_daihatsu() {
        return bb_mobil_daihatsu;
    }

    public void setBb_mobil_daihatsu(String bb_mobil_daihatsu) {
        this.bb_mobil_daihatsu = bb_mobil_daihatsu;
    }

    public String getBb_mobil_toyota() {
        return bb_mobil_toyota;
    }

    public void setBb_mobil_toyota(String bb_mobil_toyota) {
        this.bb_mobil_toyota = bb_mobil_toyota;
    }

    public String getBb_mobil_honda() {
        return bb_mobil_honda;
    }

    public void setBb_mobil_honda(String bb_mobil_honda) {
        this.bb_mobil_honda = bb_mobil_honda;
    }

    public String getTransmisi_mobil_daihatsu() {
        return transmisi_mobil_daihatsu;
    }

    public void setTransmisi_mobil_daihatsu(String transmisi_mobil_daihatsu) {
        this.transmisi_mobil_daihatsu = transmisi_mobil_daihatsu;
    }

    public String getTransmisi_mobil_toyota() {
        return transmisi_mobil_toyota;
    }

    public void setTransmisi_mobil_toyota(String transmisi_mobil_toyota) {
        this.transmisi_mobil_toyota = transmisi_mobil_toyota;
    }

    public String getTransmisi_mobil_honda() {
        return transmisi_mobil_honda;
    }

    public void setTransmisi_mobil_honda(String transmisi_mobil_honda) {
        this.transmisi_mobil_honda = transmisi_mobil_honda;
    }

    public String getHarga_mobil_daihatsu() {
        return harga_mobil_daihatsu;
    }

    public void setHarga_mobil_daihatsu(String harga_mobil_daihatsu) {
        this.harga_mobil_daihatsu = harga_mobil_daihatsu;
    }

    public String getHarga_mobil_toyota() {
        return harga_mobil_toyota;
    }

    public void setHarga_mobil_toyota(String harga_mobil_toyota) {
        this.harga_mobil_toyota = harga_mobil_toyota;
    }

    public String getHarga_mobil_honda() {
        return harga_mobil_honda;
    }

    public void setHarga_mobil_honda(String harga_mobil_honda) {
        this.harga_mobil_honda = harga_mobil_honda;
    }

    public String getDesc_mobil_daihatsu() {
        return desc_mobil_daihatsu;
    }

    public void setDesc_mobil_daihatsu(String desc_mobil_daihatsu) {
        this.desc_mobil_daihatsu = desc_mobil_daihatsu;
    }

    public String getDesc_mobil_toyota() {
        return desc_mobil_toyota;
    }

    public void setDesc_mobil_toyota(String desc_mobil_toyota) {
        this.desc_mobil_toyota = desc_mobil_toyota;
    }

    public String getDesc_mobil_honda() {
        return desc_mobil_honda;
    }

    public void setDesc_mobil_honda(String desc_mobil_honda) {
        this.desc_mobil_honda = desc_mobil_honda;
    }

    public String getAlamat_dealer_mobil_daihatsu() {
        return alamat_dealer_mobil_daihatsu;
    }

    public void setAlamat_dealer_mobil_daihatsu(String alamat_dealer_mobil_daihatsu) {
        this.alamat_dealer_mobil_daihatsu = alamat_dealer_mobil_daihatsu;
    }

    public String getAlamat_dealer_mobil_toyota() {
        return alamat_dealer_mobil_toyota;
    }

    public void setAlamat_dealer_mobil_toyota(String alamat_dealer_mobil_toyota) {
        this.alamat_dealer_mobil_toyota = alamat_dealer_mobil_toyota;
    }

    public String getAlamat_dealer_mobil_honda() {
        return alamat_dealer_mobil_honda;
    }

    public void setAlamat_dealer_mobil_honda(String alamat_dealer_mobil_honda) {
        this.alamat_dealer_mobil_honda = alamat_dealer_mobil_honda;
    }

    public String getNo_tlp_mobil_daihatsu() {
        return no_tlp_mobil_daihatsu;
    }

    public void setNo_tlp_mobil_daihatsu(String no_tlp_mobil_daihatsu) {
        this.no_tlp_mobil_daihatsu = no_tlp_mobil_daihatsu;
    }

    public String getNo_tlp_mobil_toyota() {
        return no_tlp_mobil_toyota;
    }

    public void setNo_tlp_mobil_toyota(String no_tlp_mobil_toyota) {
        this.no_tlp_mobil_toyota = no_tlp_mobil_toyota;
    }

    public String getNo_tlp_mobil_honda() {
        return no_tlp_mobil_honda;
    }

    public void setNo_tlp_mobil_honda(String no_tlp_mobil_honda) {
        this.no_tlp_mobil_honda = no_tlp_mobil_honda;
    }

    public String getId_mobilall() {
        return id_mobilall;
    }

    public void setId_mobilall(String id_mobilall) {
        this.id_mobilall = id_mobilall;
    }

    public String getLink_img_all() {
        return link_img_all;
    }

    public void setLink_img_all(String link_img_all) {
        this.link_img_all = link_img_all;
    }

    public String getNama_mobil() {
        return nama_mobil;
    }

    public void setNama_mobil(String nama_mobil) {
        this.nama_mobil = nama_mobil;
    }

    public String getVarian_mobil() {
        return varian_mobil;
    }

    public void setVarian_mobil(String varian_mobil) {
        this.varian_mobil = varian_mobil;
    }

    public String getTipebody_mobil_all() {
        return tipebody_mobil_all;
    }

    public String getBb_mobil() {
        return bb_mobil;
    }

    public void setBb_mobil(String bb_mobil) {
        this.bb_mobil = bb_mobil;
    }

    public String getTransmisi_mobil() {
        return transmisi_mobil;
    }

    public void setTransmisi_mobil(String transmisi_mobil) {
        this.transmisi_mobil = transmisi_mobil;
    }

    public String getHarga_mobil() {
        return harga_mobil;
    }

    public void setHarga_mobil(String harga_mobil) {
        this.harga_mobil = harga_mobil;
    }

    public void setTipebody_mobil_all(String tipebody_mobil_all) {
        this.tipebody_mobil_all = tipebody_mobil_all;
    }

    public String getDesc_mobil_all() {
        return desc_mobil_all;
    }

    public void setDesc_mobil_all(String desc_mobil_all) {
        this.desc_mobil_all = desc_mobil_all;
    }

    public String getAlamat_dealer_mobil_all() {
        return alamat_dealer_mobil_all;
    }

    public void setAlamat_dealer_mobil_all(String alamat_dealer_mobil_all) {
        this.alamat_dealer_mobil_all = alamat_dealer_mobil_all;
    }

    public String getNo_tlp_mobil_all() {
        return no_tlp_mobil_all;
    }

    public void setNo_tlp_mobil_all(String no_tlp_mobil_all) {
        this.no_tlp_mobil_all = no_tlp_mobil_all;
    }

}
